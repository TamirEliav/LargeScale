%   The GoogleEarth Toolbox for MATLAB can be used to export
%   data from MATLAB to a KML or KMZ file, which is GoogleEarth's
%   native file format.
%   
%   <a href="matlab:open_content_html">Click for HTML documentation</a>

